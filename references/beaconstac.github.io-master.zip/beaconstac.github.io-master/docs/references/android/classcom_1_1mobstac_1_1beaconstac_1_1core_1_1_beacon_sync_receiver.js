var classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_beacon_sync_receiver =
[
    [ "onFailure", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_beacon_sync_receiver.html#a0cca5dbb3762eb888f04b98875e7a387", null ],
    [ "onReceive", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_beacon_sync_receiver.html#a95d893655efc6763d8a1d410fd057849", null ],
    [ "onSuccess", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_beacon_sync_receiver.html#a5c60d2bf19f7549e41a1df48b8aa9970", null ]
];