var interfacecom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action_1_1_webhook_handler =
[
    [ "onError", "interfacecom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action_1_1_webhook_handler.html#aff61865163ae6573bdb028f1f9ce8eea", null ],
    [ "onSuccess", "interfacecom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action_1_1_webhook_handler.html#aa92443abf9a4ab8f367f6be530a646f5", null ]
];