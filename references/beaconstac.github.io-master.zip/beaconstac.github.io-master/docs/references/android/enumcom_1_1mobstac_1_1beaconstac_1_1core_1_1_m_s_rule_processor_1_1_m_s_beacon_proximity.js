var enumcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_rule_processor_1_1_m_s_beacon_proximity =
[
    [ "MSBeaconProximity", "enumcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_rule_processor_1_1_m_s_beacon_proximity.html#a5d30e6968bf8455e3faf82662c7edd1e", null ],
    [ "MSBeaconProximityFar", "enumcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_rule_processor_1_1_m_s_beacon_proximity.html#a6c53725fc0868ac76cf2600fe39a3846", null ],
    [ "MSBeaconProximityImmediate", "enumcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_rule_processor_1_1_m_s_beacon_proximity.html#addda69e494a11071921db365eebb0e94", null ],
    [ "MSBeaconProximityNear", "enumcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_rule_processor_1_1_m_s_beacon_proximity.html#ad58753920f018045a7366e7088fadb70", null ],
    [ "MSBeaconProximityNone", "enumcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_rule_processor_1_1_m_s_beacon_proximity.html#a5276f2d46c41291cd5ec331aaaa6b2f6", null ]
];