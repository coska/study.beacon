var classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media =
[
    [ "MSMedia", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html#a1135347d63583c21e31afe349bbdb0a6", null ],
    [ "getContentType", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html#aac23953e02f1ce6486cbb24f70d22144", null ],
    [ "getCreated", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html#a11885beef174e167222c472de60cd4a3", null ],
    [ "getExpiryDate", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html#a04e215b85e410e5e51a3dff420c6497c", null ],
    [ "getMediaID", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html#a7a1af3266620613f2e29e5fb981a0509", null ],
    [ "getMediaUrl", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html#a01563c46601dc989c0fa233c198db224", null ],
    [ "getModified", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html#acd2b356b892afc50d4f904c55a13ed6c", null ],
    [ "getName", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html#aac9c74d8cd302f9c7b598f8ef0ec9259", null ],
    [ "getOrganizationId", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html#af7e6a0e831a82a7bc990d20ccb7538b8", null ],
    [ "getTags", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html#af8d97394f99756da906f664fcb1df789", null ],
    [ "setExpiryDate", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html#a1327c6413b8c85e0213fa7b05714b78f", null ],
    [ "setMediaID", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html#a7a67ac327c2e979b136fb03acd776fb4", null ],
    [ "setTags", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html#a4986678c982ef17438b83f54d7c4239a", null ]
];