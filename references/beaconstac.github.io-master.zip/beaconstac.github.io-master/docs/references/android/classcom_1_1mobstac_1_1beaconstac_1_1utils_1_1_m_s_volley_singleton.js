var classcom_1_1mobstac_1_1beaconstac_1_1utils_1_1_m_s_volley_singleton =
[
    [ "getRequestQueue", "classcom_1_1mobstac_1_1beaconstac_1_1utils_1_1_m_s_volley_singleton.html#aaf59e600cadc6a3d9c81e8c11be01782", null ]
];