var classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_model_base =
[
    [ "ModelBase", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_model_base.html#abcae77fde52668dea00f51c45fc4aacd", null ]
];