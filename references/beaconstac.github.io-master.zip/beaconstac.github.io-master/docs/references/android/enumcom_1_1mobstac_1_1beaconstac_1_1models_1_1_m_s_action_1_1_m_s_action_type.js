var enumcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action_1_1_m_s_action_type =
[
    [ "MSActionType", "enumcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action_1_1_m_s_action_type.html#acdfa87b7c4c7ea90d3f2886b06688754", null ],
    [ "MSActionTypeCard", "enumcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action_1_1_m_s_action_type.html#a49788f12d0490c37b24e3c3754dc6621", null ],
    [ "MSActionTypeCustom", "enumcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action_1_1_m_s_action_type.html#abfc8b9901c48c3a9f98b8ed0e4cac1e0", null ],
    [ "MSActionTypeNone", "enumcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action_1_1_m_s_action_type.html#afa694d18a924e0505075b3a4b3af9d0b", null ],
    [ "MSActionTypeNotification", "enumcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action_1_1_m_s_action_type.html#a1269704a84c209ce6ec82cdecc67f65d", null ],
    [ "MSActionTypePopup", "enumcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action_1_1_m_s_action_type.html#a06af03fd20b529f4e92961f8767597b2", null ],
    [ "MSActionTypeWebhook", "enumcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action_1_1_m_s_action_type.html#ab73135802939a073fc89aabf97ee8a08", null ],
    [ "MSActionTypeWebpage", "enumcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action_1_1_m_s_action_type.html#af8355e9a576c60ce0a99807b8c5702f6", null ]
];