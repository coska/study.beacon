var classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_notifications =
[
    [ "MSNotifications", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_notifications.html#a9674fc6096e7a88ed9da4d508dbc8257", null ],
    [ "syncNotificationsWithServer", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_notifications.html#a662809a67d2d90686439a07fc6e10757", null ]
];