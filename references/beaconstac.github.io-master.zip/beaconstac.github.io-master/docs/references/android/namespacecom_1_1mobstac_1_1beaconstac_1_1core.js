var namespacecom_1_1mobstac_1_1beaconstac_1_1core =
[
    [ "Beaconstac", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_beaconstac.html", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_beaconstac" ],
    [ "BeaconstacReceiver", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_beaconstac_receiver.html", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_beaconstac_receiver" ],
    [ "BeaconSyncReceiver", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_beacon_sync_receiver.html", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_beacon_sync_receiver" ],
    [ "DismissNotification", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_dismiss_notification.html", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_dismiss_notification" ],
    [ "MSBLEService", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_b_l_e_service.html", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_b_l_e_service" ],
    [ "MSConstants", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_constants.html", null ],
    [ "MSNotifications", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_notifications.html", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_notifications" ],
    [ "MSPlace", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_place.html", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_place" ],
    [ "MSRuleProcessor", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_rule_processor.html", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_rule_processor" ],
    [ "PlaceSyncReceiver", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_place_sync_receiver.html", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_place_sync_receiver" ],
    [ "RuleSyncReceiver", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_rule_sync_receiver.html", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_rule_sync_receiver" ],
    [ "WebView", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_web_view.html", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_web_view" ]
];