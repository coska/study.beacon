var classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_dismiss_notification =
[
    [ "onReceive", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_dismiss_notification.html#a00196f6762f91d62ba3e157422f9f7a7", null ]
];