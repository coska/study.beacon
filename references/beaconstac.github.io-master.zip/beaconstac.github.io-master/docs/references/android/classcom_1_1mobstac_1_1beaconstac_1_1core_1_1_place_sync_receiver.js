var classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_place_sync_receiver =
[
    [ "onFailure", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_place_sync_receiver.html#acd220f160d657562b07e0d7d0856d0ec", null ],
    [ "onReceive", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_place_sync_receiver.html#aaa965334351f3ccd01f11b82c63a3b37", null ],
    [ "onSuccess", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_place_sync_receiver.html#af58774d98630f8f0e2eb174bbf742d14", null ]
];