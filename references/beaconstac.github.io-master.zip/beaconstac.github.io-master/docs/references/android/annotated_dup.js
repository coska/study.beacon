var annotated_dup =
[
    [ "com", null, [
      [ "mobstac", null, [
        [ "beaconstac", null, [
          [ "core", "namespacecom_1_1mobstac_1_1beaconstac_1_1core.html", "namespacecom_1_1mobstac_1_1beaconstac_1_1core" ],
          [ "models", null, [
            [ "ModelBase", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_model_base.html", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_model_base" ],
            [ "MSAction", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action.html", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_action" ],
            [ "MSBeacon", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_beacon.html", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_beacon" ],
            [ "MSCard", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_card.html", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_card" ],
            [ "MSMedia", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media.html", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_media" ],
            [ "MSNotifData", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_notif_data.html", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_notif_data" ],
            [ "MSNotifs", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_notifs.html", null ],
            [ "MSRule", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_rule.html", null ],
            [ "MSRuleBeacon", "classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_rule_beacon.html", null ]
          ] ],
          [ "provider", null, [
            [ "MSContentProvider", "classcom_1_1mobstac_1_1beaconstac_1_1provider_1_1_m_s_content_provider.html", null ]
          ] ],
          [ "utils", "namespacecom_1_1mobstac_1_1beaconstac_1_1utils.html", "namespacecom_1_1mobstac_1_1beaconstac_1_1utils" ]
        ] ]
      ] ]
    ] ]
];