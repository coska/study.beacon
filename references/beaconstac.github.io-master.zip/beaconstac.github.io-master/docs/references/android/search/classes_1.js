var searchData=
[
  ['dismissnotification',['DismissNotification',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_dismiss_notification.html',1,'com::mobstac::beaconstac::core']]]
];
