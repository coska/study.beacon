var searchData=
[
  ['placesyncreceiver',['PlaceSyncReceiver',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_place_sync_receiver.html',1,'com::mobstac::beaconstac::core']]]
];
