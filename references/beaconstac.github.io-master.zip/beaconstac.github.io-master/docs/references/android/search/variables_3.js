var searchData=
[
  ['intent_5fprefix',['INTENT_PREFIX',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_constants.html#a233a544dc185cfc7501f94406a3a1a49',1,'com::mobstac::beaconstac::core::MSConstants']]],
  ['is_5fdebug',['IS_DEBUG',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_constants.html#a04fd562328a5a1b0be9aa93fdca669e5',1,'com::mobstac::beaconstac::core::MSConstants']]],
  ['iso8601format',['iso8601Format',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_constants.html#ac8e9ba069c7772cd3d8d4268b9a49280',1,'com::mobstac::beaconstac::core::MSConstants']]]
];
