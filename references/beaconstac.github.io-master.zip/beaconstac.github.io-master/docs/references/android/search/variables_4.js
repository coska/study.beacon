var searchData=
[
  ['mgeofencelist',['mGeofenceList',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_place.html#a017075a8b5bba1c66d3f6cb1ae3b59cb',1,'com::mobstac::beaconstac::core::MSPlace']]],
  ['mgoogleapiclient',['mGoogleApiClient',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_place.html#ad533b66870a9d20bd25ae47fa4c9b7c2',1,'com::mobstac::beaconstac::core::MSPlace']]],
  ['min_5fbroadcast_5fdelay',['MIN_BROADCAST_DELAY',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_constants.html#a04ecddcc7963e30af3e320c913b90ca1',1,'com::mobstac::beaconstac::core::MSConstants']]]
];
