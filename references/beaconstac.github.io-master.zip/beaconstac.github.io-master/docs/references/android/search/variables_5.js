var searchData=
[
  ['ranging_5fwait_5fduration',['RANGING_WAIT_DURATION',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_constants.html#a33864a389bb6db222b99b87ee7472d51',1,'com::mobstac::beaconstac::core::MSConstants']]],
  ['rssi_5fentry_5fthreshold',['RSSI_ENTRY_THRESHOLD',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_constants.html#a31755c80718d9f78ee122909c90097af',1,'com::mobstac::beaconstac::core::MSConstants']]],
  ['rssi_5fexit_5fthreshold',['RSSI_EXIT_THRESHOLD',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_constants.html#a8d509fea0b3557ec967114b2c83be239',1,'com::mobstac::beaconstac::core::MSConstants']]]
];
