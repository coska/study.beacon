var searchData=
[
  ['event_5franged_5fbeacon',['EVENT_RANGED_BEACON',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_constants.html#ae3f9d943eaff6aff6dd69f8734c302ac',1,'com::mobstac::beaconstac::core::MSConstants']]]
];
