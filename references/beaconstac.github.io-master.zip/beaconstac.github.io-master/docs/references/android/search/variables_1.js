var searchData=
[
  ['beacon_5fcache_5fduration',['BEACON_CACHE_DURATION',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_constants.html#adc7ee05f898bb968fbca591f3e901d0e',1,'com::mobstac::beaconstac::core::MSConstants']]],
  ['ble_5fscan_5fduration_5factive_5fkey',['BLE_SCAN_DURATION_ACTIVE_KEY',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_constants.html#ac74c591d0ae86f7bbef78ad2e5f1b231',1,'com::mobstac::beaconstac::core::MSConstants']]]
];
