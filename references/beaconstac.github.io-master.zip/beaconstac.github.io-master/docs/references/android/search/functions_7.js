var searchData=
[
  ['msbeacon',['MSBeacon',['../classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_beacon.html#ab78e233e40c2761ef540bc454cf41f3f',1,'com.mobstac.beaconstac.models.MSBeacon.MSBeacon(UUID uuid, int major, int minor)'],['../classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_beacon.html#ad211985a6e0fd6f720b79f075cabe31a',1,'com.mobstac.beaconstac.models.MSBeacon.MSBeacon(Parcel p)']]],
  ['msplace',['MSPlace',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_place.html#a769070e8ff0aba6d9409643addd88408',1,'com.mobstac.beaconstac.core.MSPlace.MSPlace(Context context)'],['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_place.html#a1966c88f6346afc4c664fffcde7e5ef7',1,'com.mobstac.beaconstac.core.MSPlace.MSPlace(Parcel p)']]],
  ['msruleprocessor',['MSRuleProcessor',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_rule_processor.html#a516a0b9648d499c3d2acb746b6fd6406',1,'com::mobstac::beaconstac::core::MSRuleProcessor']]]
];
