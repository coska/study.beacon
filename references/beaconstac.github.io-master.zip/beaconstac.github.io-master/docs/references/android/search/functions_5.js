var searchData=
[
  ['init',['init',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_b_l_e_service.html#a2790813c9611240416fd979f3dd89d16',1,'com::mobstac::beaconstac::core::MSBLEService']]],
  ['isautomanagebluetooth',['isAutoManageBluetooth',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_beaconstac.html#a298d996a1eff6bf6b7cda8640b4e7a55',1,'com::mobstac::beaconstac::core::Beaconstac']]],
  ['isfar',['isFar',['../classcom_1_1mobstac_1_1beaconstac_1_1models_1_1_m_s_beacon.html#a799667e87f94ff5e4685d8eec1bc70b5',1,'com::mobstac::beaconstac::models::MSBeacon']]],
  ['ispowersaving',['isPowerSaving',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_beaconstac.html#a9269fb42676dba028164d53fe2105821',1,'com::mobstac::beaconstac::core::Beaconstac']]],
  ['isscreenon',['isScreenOn',['../classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_beaconstac.html#a0e29c1033f6afa26d8b972784a0f7b74',1,'com::mobstac::beaconstac::core::Beaconstac']]]
];
