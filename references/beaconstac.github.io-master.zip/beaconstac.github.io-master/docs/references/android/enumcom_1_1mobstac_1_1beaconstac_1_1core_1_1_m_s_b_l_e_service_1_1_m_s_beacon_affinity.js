var enumcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_b_l_e_service_1_1_m_s_beacon_affinity =
[
    [ "MSBeaconAffinity", "enumcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_b_l_e_service_1_1_m_s_beacon_affinity.html#a675857c88792ad7d0ee5aa9498ccef45", null ],
    [ "MSBeaconAffinityHigh", "enumcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_b_l_e_service_1_1_m_s_beacon_affinity.html#a22c3cee301d5bfeb07a2e953576e22f3", null ],
    [ "MSBeaconAffinityLow", "enumcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_b_l_e_service_1_1_m_s_beacon_affinity.html#a20c6ab6b46d17cab3fc3617726a5d880", null ],
    [ "MSBeaconAffinityMedium", "enumcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_b_l_e_service_1_1_m_s_beacon_affinity.html#ac386c49fa84443eda8b92979b7d9c596", null ],
    [ "MSBeaconAffinityNone", "enumcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_b_l_e_service_1_1_m_s_beacon_affinity.html#a50fb96d8624656bc55de1c1c69d9670c", null ],
    [ "value", "enumcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_b_l_e_service_1_1_m_s_beacon_affinity.html#a91d1822a566747e7998806f1037155be", null ]
];