var classcom_1_1mobstac_1_1beaconstac_1_1utils_1_1_m_s_exception =
[
    [ "MSException", "classcom_1_1mobstac_1_1beaconstac_1_1utils_1_1_m_s_exception.html#ad81006a38bd85c64b3a40fc98a35baf5", null ],
    [ "MSException", "classcom_1_1mobstac_1_1beaconstac_1_1utils_1_1_m_s_exception.html#a467f3c04bedadaf67dda49d9c6dcc76a", null ]
];