var namespaces =
[
    [ "com", null, [
      [ "mobstac", null, [
        [ "beaconstac", null, [
          [ "core", "namespacecom_1_1mobstac_1_1beaconstac_1_1core.html", null ],
          [ "utils", "namespacecom_1_1mobstac_1_1beaconstac_1_1utils.html", null ]
        ] ]
      ] ]
    ] ]
];