var classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_b_l_e_service_1_1_m_s_b_l_e_service_binder =
[
    [ "getService", "classcom_1_1mobstac_1_1beaconstac_1_1core_1_1_m_s_b_l_e_service_1_1_m_s_b_l_e_service_binder.html#a30cfef78000be5d1503d7fce351a0725", null ]
];