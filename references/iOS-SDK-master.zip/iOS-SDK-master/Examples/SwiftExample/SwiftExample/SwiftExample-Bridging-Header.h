//
//  SwiftExample-Bridging-Header.h
//  SwiftExample
//
//  Copyright © 2015 Mobstac Inc. All rights reserved.
//

#ifndef SwiftExample_Bridging_Header_h
#define SwiftExample_Bridging_Header_h

#import <Beaconstac/Beaconstac.h>

#endif