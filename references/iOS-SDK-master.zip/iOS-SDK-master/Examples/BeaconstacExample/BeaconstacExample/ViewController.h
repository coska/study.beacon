//
//  ViewController.h
//  BeaconstacExample
//
//  Copyright (c) 2015 Mobstac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end

